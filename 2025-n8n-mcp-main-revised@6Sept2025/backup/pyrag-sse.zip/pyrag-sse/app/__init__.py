"""App module for PyRAGDoc SSE Server"""
