"""Data models for PyRAGDoc."""
