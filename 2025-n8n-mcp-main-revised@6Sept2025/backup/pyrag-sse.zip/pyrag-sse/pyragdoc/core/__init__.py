"""Core functionality for PyRAGDoc."""
